import React from 'react';
import ReactDOM from 'react-dom';

import nivel1 from './proyectocomp/nivel1'
import './styles/styles.scss'

// ReactDOM.render(<Header/>, document.getElementById('app'));
